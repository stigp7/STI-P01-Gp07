angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('mainMenu.home', {
    url: '/page1',
    views: {
      'side-menu21': {
        templateUrl: 'templates/home.html',
        controller: 'homeCtrl'
      }
    }
  })

  .state('mainMenu.gameQuiz', {
    url: '/page2',
    views: {
      'side-menu21': {
        templateUrl: 'templates/gameQuiz.html',
        controller: 'gameQuizCtrl'
      }
    }
  })

  .state('gameQuiz2', {
    url: '/page13',
    templateUrl: 'templates/gameQuiz2.html',
    controller: 'gameQuiz2Ctrl'
  })

  .state('gameQuiz3', {
    url: '/page14',
    templateUrl: 'templates/gameQuiz3.html',
    controller: 'gameQuiz3Ctrl'
  })

  .state('gameQuiz4', {
    url: '/page15',
    templateUrl: 'templates/gameQuiz4.html',
    controller: 'gameQuiz4Ctrl'
  })

  .state('mainMenu.videos', {
    url: '/page3',
    views: {
      'side-menu21': {
        templateUrl: 'templates/videos.html',
        controller: 'videosCtrl'
      }
    }
  })

  .state('mainMenu.letSChat', {
    url: '/page5',
    views: {
      'side-menu21': {
        templateUrl: 'templates/letSChat.html',
        controller: 'letSChatCtrl'
      }
    }
  })

  .state('mainMenu.newsArticles', {
    url: '/page6',
    views: {
      'side-menu21': {
        templateUrl: 'templates/newsArticles.html',
        controller: 'newsArticlesCtrl'
      }
    }
  })

  .state('mainMenu.article1', {
    url: '/page17',
    views: {
      'side-menu21': {
        templateUrl: 'templates/article1.html',
        controller: 'article1Ctrl'
      }
    }
  })

  .state('mainMenu.article3', {
    url: '/page19',
    views: {
      'side-menu21': {
        templateUrl: 'templates/article3.html',
        controller: 'article3Ctrl'
      }
    }
  })

  .state('mainMenu.article2', {
    url: '/page18',
    views: {
      'side-menu21': {
        templateUrl: 'templates/article2.html',
        controller: 'article2Ctrl'
      }
    }
  })

  .state('mainMenu.article4', {
    url: '/page20',
    views: {
      'side-menu21': {
        templateUrl: 'templates/article4.html',
        controller: 'article4Ctrl'
      }
    }
  })

  .state('mainMenu.article5', {
    url: '/page21',
    views: {
      'side-menu21': {
        templateUrl: 'templates/article5.html',
        controller: 'article5Ctrl'
      }
    }
  })

  .state('mainMenu.article6', {
    url: '/page22',
    views: {
      'side-menu21': {
        templateUrl: 'templates/article6.html',
        controller: 'article6Ctrl'
      }
    }
  })

  .state('mainMenu', {
    url: '/side-menu21',
    templateUrl: 'templates/mainMenu.html',
    abstract:true
  })

  .state('messageSent', {
    url: '/page7',
    templateUrl: 'templates/messageSent.html',
    controller: 'messageSentCtrl'
  })

  .state('youAreAWinner', {
    url: '/page8',
    templateUrl: 'templates/youAreAWinner.html',
    controller: 'youAreAWinnerCtrl'
  })

  .state('mainMenu.aboutUs', {
    url: '/page9',
    views: {
      'side-menu21': {
        templateUrl: 'templates/aboutUs.html',
        controller: 'aboutUsCtrl'
      }
    }
  })

  .state('mainMenu.feedback', {
    url: '/page10',
    views: {
      'side-menu21': {
        templateUrl: 'templates/feedback.html',
        controller: 'feedbackCtrl'
      }
    }
  })

  .state('mainMenu.feedbackSent', {
    url: '/page11',
    views: {
      'side-menu21': {
        templateUrl: 'templates/feedbackSent.html',
        controller: 'feedbackSentCtrl'
      }
    }
  })

  .state('mainMenu.chatHistory', {
    url: '/page12',
    views: {
      'side-menu21': {
        templateUrl: 'templates/chatHistory.html',
        controller: 'chatHistoryCtrl'
      }
    }
  })

  .state('mainMenu.feedbacksOfTheWeek', {
    url: '/page16',
    views: {
      'side-menu21': {
        templateUrl: 'templates/feedbacksOfTheWeek.html',
        controller: 'feedbacksOfTheWeekCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/side-menu21/page1')

  

});