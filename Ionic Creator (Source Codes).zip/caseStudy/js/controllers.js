angular.module('app.controllers', [])
  
.controller('homeCtrl', function($scope) {

})
   
.controller('gameQuizCtrl', function($scope) {

})
   
.controller('gameQuiz2Ctrl', function($scope) {

})
   
.controller('gameQuiz3Ctrl', function($scope) {

})
   
.controller('gameQuiz4Ctrl', function($scope) {

})
   
.controller('videosCtrl', function($scope) {

})
   
.controller('letSChatCtrl', function($scope) {

})
   
.controller('newsArticlesCtrl', function($scope) {

})
   
.controller('article1Ctrl', function($scope) {

})
   
.controller('article3Ctrl', function($scope) {

})
   
.controller('article2Ctrl', function($scope) {

})
   
.controller('article4Ctrl', function($scope) {

})
   
.controller('article5Ctrl', function($scope) {

})
   
.controller('article6Ctrl', function($scope) {

})
      
.controller('messageSentCtrl', function($scope) {

})
   
.controller('youAreAWinnerCtrl', function($scope) {

})
   
.controller('aboutUsCtrl', function($scope) {

})
   
.controller('feedbackCtrl', function($scope) {

})
   
.controller('feedbackSentCtrl', function($scope) {

})
   
.controller('chatHistoryCtrl', function($scope) {

})
   
.controller('feedbacksOfTheWeekCtrl', function($scope) {

})
 